// Public connection details for Supabase project "Neo v1".
// The publishable key is safe to ship in an app: Row Level Security
// keeps every table private to Max's signed-in account.
// NEVER put the service_role key, Groq key or any AI key in this app.
const supabaseUrl = 'https://jsjxklslickhahyuajcc.supabase.co';
const supabasePublishableKey = 'sb_publishable_C_xF7SRRnrfzYN1WorHUZQ_x99_HxjS';
