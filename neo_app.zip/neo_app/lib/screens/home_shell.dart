import 'package:flutter/material.dart';

import '../main.dart';
import 'activity_screen.dart';
import 'approvals_screen.dart';
import 'chat_screen.dart';
import 'settings_screen.dart';
import 'spending_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;

  static const _titles = ['Chat', 'Activity', 'Approvals', 'Spending'];
  static const _screens = [ChatScreen(), ActivityScreen(), ApprovalsScreen(), SpendingScreen()];

  // Live count of pending approvals for the badge.
  late final Stream<int> _pendingCount = supabase
      .from('approvals')
      .stream(primaryKey: ['id'])
      .eq('status', 'pending')
      .map((rows) => rows.length);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_tab]),
        actions: [
          IconButton(
            tooltip: 'Settings',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      body: IndexedStack(index: _tab, children: _screens),
      bottomNavigationBar: StreamBuilder<int>(
        stream: _pendingCount,
        builder: (context, snap) {
          final pending = snap.data ?? 0;
          return NavigationBar(
            selectedIndex: _tab,
            onDestinationSelected: (i) => setState(() => _tab = i),
            destinations: [
              const NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Chat'),
              const NavigationDestination(icon: Icon(Icons.timeline_outlined), selectedIcon: Icon(Icons.timeline), label: 'Activity'),
              NavigationDestination(
                icon: Badge(isLabelVisible: pending > 0, label: Text('$pending'), child: const Icon(Icons.task_alt_outlined)),
                selectedIcon: Badge(isLabelVisible: pending > 0, label: Text('$pending'), child: const Icon(Icons.task_alt)),
                label: 'Approvals',
              ),
              const NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), selectedIcon: Icon(Icons.account_balance_wallet), label: 'Spending'),
            ],
          );
        },
      ),
    );
  }
}
