import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../main.dart';

/// This month's spending from `transactions`.
/// Money spent = debit rows of type purchase / p2p / withdrawal / fee.
/// Refunds, reversals, top-ups and transfers between Max's own cards are not spending.
class SpendingScreen extends StatefulWidget {
  const SpendingScreen({super.key});

  @override
  State<SpendingScreen> createState() => _SpendingScreenState();
}

class _SpendingScreenState extends State<SpendingScreen> with AutomaticKeepAliveClientMixin {
  late Future<List<Map<String, dynamic>>> _future = _load();

  static const _spendTypes = {'purchase', 'p2p', 'withdrawal', 'fee'};

  Future<List<Map<String, dynamic>>> _load() {
    final now = DateTime.now();
    final monthStart = DateTime(now.year, now.month).toUtc().toIso8601String();
    return supabase
        .from('transactions')
        .select()
        .gte('ts', monthStart)
        .order('ts', ascending: false);
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final theme = Theme.of(context);
    final money = NumberFormat.decimalPattern('ru');

    return RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (context, snap) {
          if (snap.hasError) {
            return ListView(children: [Padding(padding: const EdgeInsets.all(24), child: Text('Error: ${snap.error}'))]);
          }
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final rows = snap.data!;

          // Totals per currency and per category (spending only).
          final totals = <String, double>{};
          final byCategory = <String, double>{};
          for (final r in rows) {
            if (r['direction'] != 'debit' || !_spendTypes.contains(r['type'])) continue;
            final amount = (r['amount'] as num?)?.toDouble() ?? 0;
            final cur = r['currency']?.toString() ?? 'UZS';
            totals[cur] = (totals[cur] ?? 0) + amount;
            if (cur == 'UZS') {
              final cat = r['category']?.toString() ?? 'Uncategorized';
              byCategory[cat] = (byCategory[cat] ?? 0) + amount;
            }
          }
          final cats = byCategory.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
          final maxCat = cats.isEmpty ? 1.0 : cats.first.value;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text(DateFormat('LLLL yyyy').format(DateTime.now()), style: theme.textTheme.titleMedium),
              const SizedBox(height: 4),
              if (totals.isEmpty)
                Text('0 UZS', style: theme.textTheme.headlineMedium)
              else
                for (final e in totals.entries)
                  Text('${money.format(e.value.round())} ${e.key}', style: theme.textTheme.headlineMedium),
              const SizedBox(height: 20),
              if (cats.isNotEmpty) ...[
                Text('By category (UZS)', style: theme.textTheme.titleSmall),
                const SizedBox(height: 8),
                for (final c in cats)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [Expanded(child: Text(c.key)), Text(money.format(c.value.round()))]),
                        const SizedBox(height: 4),
                        LinearProgressIndicator(value: c.value / maxCat, minHeight: 6, borderRadius: BorderRadius.circular(3)),
                      ],
                    ),
                  ),
                const SizedBox(height: 20),
              ],
              Text('Transactions', style: theme.textTheme.titleSmall),
              if (rows.isEmpty)
                const Padding(padding: EdgeInsets.symmetric(vertical: 24), child: Text('No transactions this month yet.')),
              for (final r in rows) _TxTile(row: r, money: money),
            ],
          );
        },
      ),
    );
  }
}

class _TxTile extends StatelessWidget {
  const _TxTile({required this.row, required this.money});
  final Map<String, dynamic> row;
  final NumberFormat money;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final ts = DateTime.tryParse(row['ts']?.toString() ?? '')?.toLocal();
    final debit = row['direction'] == 'debit';
    final amount = (row['amount'] as num?)?.toDouble() ?? 0;
    final card = row['card_mask'] != null ? ' · *${row['card_mask']}' : '';
    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(row['merchant_norm']?.toString() ?? row['merchant_raw']?.toString() ?? row['type']?.toString() ?? ''),
      subtitle: Text('${row['category'] ?? 'Uncategorized'}$card${ts != null ? ' · ${DateFormat('d MMM HH:mm').format(ts)}' : ''}'),
      trailing: Text(
        '${debit ? '−' : '+'}${money.format(amount.round())} ${row['currency'] ?? 'UZS'}',
        style: TextStyle(color: debit ? theme.colorScheme.onSurface : Colors.green, fontWeight: FontWeight.w600),
      ),
    );
  }
}
