import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../main.dart';

/// Live, newest-first list of everything Neo did (`activity_log`).
class ActivityScreen extends StatefulWidget {
  const ActivityScreen({super.key});

  @override
  State<ActivityScreen> createState() => _ActivityScreenState();
}

class _ActivityScreenState extends State<ActivityScreen> with AutomaticKeepAliveClientMixin {
  String _filter = 'all';

  late final Stream<List<Map<String, dynamic>>> _log = supabase
      .from('activity_log')
      .stream(primaryKey: ['id'])
      .order('ts', ascending: false)
      .limit(200);

  static const _filters = ['all', 'telegram', 'gmail', 'notification', 'sms', 'app', 'schedule'];

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(
      children: [
        SizedBox(
          height: 52,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            children: [
              for (final f in _filters)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(f == 'all' ? 'All' : f[0].toUpperCase() + f.substring(1)),
                    selected: _filter == f,
                    onSelected: (_) => setState(() => _filter = f),
                  ),
                ),
            ],
          ),
        ),
        Expanded(
          child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: _log,
            builder: (context, snap) {
              if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final rows = _filter == 'all'
                  ? snap.data!
                  : snap.data!.where((r) => r['source'] == _filter).toList();
              if (rows.isEmpty) return const Center(child: Text('Nothing yet.'));
              return ListView.separated(
                itemCount: rows.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, i) => _ActivityTile(row: rows[i]),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _ActivityTile extends StatelessWidget {
  const _ActivityTile({required this.row});
  final Map<String, dynamic> row;

  IconData get _icon => switch (row['source']) {
        'telegram' => Icons.send_outlined,
        'gmail' => Icons.mail_outline,
        'notification' => Icons.notifications_none,
        'sms' => Icons.sms_outlined,
        'app' => Icons.phone_android,
        'schedule' => Icons.schedule,
        _ => Icons.bolt_outlined,
      };

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final ts = DateTime.tryParse(row['ts']?.toString() ?? '')?.toLocal();
    final status = row['status']?.toString() ?? 'ok';
    final statusColor = switch (status) {
      'error' => theme.colorScheme.error,
      'pending' => Colors.orange,
      'skipped' => theme.colorScheme.outline,
      _ => Colors.green,
    };
    return ListTile(
      leading: Icon(_icon),
      title: Text(row['action']?.toString() ?? ''),
      subtitle: Text([
        if (row['tool'] != null) row['tool'],
        if (ts != null) DateFormat('d MMM, HH:mm').format(ts),
      ].join(' · ')),
      trailing: Icon(Icons.circle, size: 10, color: statusColor),
      onTap: () => showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (_) => DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.6,
          builder: (context, controller) => ListView(
            controller: controller,
            padding: const EdgeInsets.all(16),
            children: [
              Text(row['action']?.toString() ?? '', style: theme.textTheme.titleLarge),
              const SizedBox(height: 8),
              Text('Status: $status'),
              const SizedBox(height: 16),
              Text('Input', style: theme.textTheme.titleSmall),
              SelectableText(_pretty(row['input'])),
              const SizedBox(height: 16),
              Text('Output', style: theme.textTheme.titleSmall),
              SelectableText(_pretty(row['output'])),
            ],
          ),
        ),
      ),
    );
  }

  static String _pretty(Object? v) {
    if (v == null) return '—';
    try {
      return const JsonEncoder.withIndent('  ').convert(v);
    } catch (_) {
      return v.toString();
    }
  }
}
