import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../main.dart';

/// Things Neo wants to do. Nothing happens until Max taps Approve;
/// n8n watches `approvals.status` and carries out approved actions.
class ApprovalsScreen extends StatelessWidget {
  const ApprovalsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final pending = supabase
        .from('approvals')
        .stream(primaryKey: ['id'])
        .eq('status', 'pending')
        .order('ts', ascending: false);

    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: pending,
      builder: (context, snap) {
        if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final rows = snap.data!;
        if (rows.isEmpty) {
          return const Center(child: Text('Nothing waiting for you ✅'));
        }
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: rows.length,
          itemBuilder: (context, i) => _ApprovalCard(row: rows[i]),
        );
      },
    );
  }
}

class _ApprovalCard extends StatefulWidget {
  const _ApprovalCard({required this.row});
  final Map<String, dynamic> row;

  @override
  State<_ApprovalCard> createState() => _ApprovalCardState();
}

class _ApprovalCardState extends State<_ApprovalCard> {
  bool _busy = false;

  Future<void> _decide(String status) async {
    setState(() => _busy = true);
    try {
      await supabase
          .from('approvals')
          .update({
            'status': status,
            'decided_at': DateTime.now().toUtc().toIso8601String(),
            'decided_via': 'app',
          })
          .eq('id', widget.row['id'])
          .eq('status', 'pending'); // never re-decide something already handled
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final row = widget.row;
    final ts = DateTime.tryParse(row['ts']?.toString() ?? '')?.toLocal();
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Chip(label: Text(row['action_type']?.toString() ?? 'action')),
                const Spacer(),
                if (ts != null) Text(DateFormat('d MMM, HH:mm').format(ts), style: theme.textTheme.labelSmall),
              ],
            ),
            const SizedBox(height: 8),
            SelectableText(row['preview_text']?.toString() ?? row['payload'].toString()),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                OutlinedButton(onPressed: _busy ? null : () => _decide('rejected'), child: const Text('Reject')),
                const SizedBox(width: 8),
                FilledButton(onPressed: _busy ? null : () => _decide('approved'), child: const Text('Approve')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
