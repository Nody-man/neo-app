import 'package:flutter/material.dart';

import '../main.dart';

/// Neo's settings, stored in the `settings` table (key → JSON value).
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final Stream<List<Map<String, dynamic>>> _settings =
      supabase.from('settings').stream(primaryKey: ['key']);

  Future<void> _set(String key, Object value) async {
    try {
      await supabase.from('settings').upsert({'key': key, 'value': value});
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Not saved: $e')));
      }
    }
  }

  Future<void> _confirmKillSwitch(bool on) async {
    if (!on) return _set('kill_switch', false);
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Stop Neo?'),
        content: const Text('Neo will stop taking any actions until you turn this off. It can still read and summarize.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Stop Neo')),
        ],
      ),
    );
    if (ok == true) await _set('kill_switch', true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: _settings,
        builder: (context, snap) {
          if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final s = {for (final r in snap.data!) r['key'] as String: r['value']};
          final kill = s['kill_switch'] == true;
          final lang = s['reply_language']?.toString() ?? 'same_as_user';
          final voice = s['voice_replies'] == true;

          return ListView(
            children: [
              SwitchListTile(
                secondary: Icon(Icons.dangerous_outlined, color: kill ? Theme.of(context).colorScheme.error : null),
                title: const Text('Kill switch'),
                subtitle: Text(kill ? 'Neo is stopped — no actions will run' : 'Neo is running'),
                value: kill,
                onChanged: _confirmKillSwitch,
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.translate),
                title: const Text('Reply language'),
                trailing: DropdownButton<String>(
                  value: const ['same_as_user', 'uz', 'ru', 'en'].contains(lang) ? lang : 'same_as_user',
                  underline: const SizedBox.shrink(),
                  items: const [
                    DropdownMenuItem(value: 'same_as_user', child: Text('Same as mine')),
                    DropdownMenuItem(value: 'uz', child: Text('Oʻzbekcha')),
                    DropdownMenuItem(value: 'ru', child: Text('Русский')),
                    DropdownMenuItem(value: 'en', child: Text('English')),
                  ],
                  onChanged: (v) => v == null ? null : _set('reply_language', v),
                ),
              ),
              SwitchListTile(
                secondary: const Icon(Icons.record_voice_over_outlined),
                title: const Text('Voice replies'),
                subtitle: const Text('Coming in the voice phase'),
                value: voice,
                onChanged: (v) => _set('voice_replies', v),
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('Sign out'),
                subtitle: Text(supabase.auth.currentUser?.email ?? ''),
                onTap: () async {
                  await supabase.auth.signOut();
                  if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
                },
              ),
            ],
          );
        },
      ),
    );
  }
}
