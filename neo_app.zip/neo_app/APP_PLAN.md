# Neo Android app — build plan

**What it is:** Max's admin panel for Neo. Chat with Neo, watch everything it does live, approve or reject its actions, see spending, and (later) let the phone forward notifications and bank alerts to Neo.

**Tech:** Flutter (Dart), built on Max's Windows PC and installed as an APK (sideloaded, no Play Store). Talks only to Supabase project "Neo v1". **No AI keys or service keys ever go in the app** — the app only has the Supabase URL and the public "publishable/anon" key, and Row Level Security keeps data private to Max's login.

## How the app talks to Neo

```
App  ──insert──▶ messages (role=user, channel=app)
                     │  Supabase Database Webhook (with secret header)
                     ▼
                 n8n "Neo — App chat" workflow ──▶ Groq ──▶ insert messages (role=neo)
                                                               │
App  ◀──────────── Supabase Realtime (live) ───────────────────┘

App ──update──▶ approvals.status = approved/rejected ──▶ n8n acts on it (plain code, not AI)
n8n ──insert──▶ activity_log ──▶ Realtime ──▶ Activity screen
```

## Screens (bottom bar: Chat · Activity · Approvals · Spending; gear icon → Settings)

| Screen | v1 (now) | Later |
|---|---|---|
| Login | Email + password (Supabase Auth). Only Max's account exists; sign-ups turned off after he registers. | Biometric unlock |
| Chat | Message list (live), text box, quick buttons ("Today's digest", "This week's spending") | Mic button (voice) |
| Activity | Live newest-first list from `activity_log`, filter by source, tap for details | Search |
| Approvals | Pending cards with preview, Approve / Reject; badge with count | Edit before approve; push notification opens the card |
| Spending | Month total, per-category totals, transaction list | Chart, fix category, budget bar |
| Settings | Kill switch, reply language, voice replies on/off, sign out | Quiet hours, app allow-list for notification forwarding, Gmail status |

## Milestones

| # | Milestone | Done when |
|---|---|---|
| A1 | Project runs on phone | `flutter run` shows the login screen on Max's phone |
| A2 | Login + live data | Max logs in; Activity shows a test row inserted from Supabase within 2 seconds |
| A3 | Chat with Neo in the app | Message typed in the app gets a Neo reply (needs n8n "App chat" workflow) |
| A4 | Approvals + Settings | Approving a test row updates it in Supabase; kill switch flips the setting |
| A5 | Spending screen | Shows totals from test transactions |
| B | Notification listener | A test WhatsApp/SMS notification lands in `incoming_items`; OTPs never leave the phone |
| C | Push notifications | Firebase push arrives with the app closed when a new approval appears |
| D | Voice | 17 of 20 spoken commands understood per language |

## Setup on Max's PC (one time)

1. Install Flutter SDK (Windows) from docs.flutter.dev and run `flutter doctor`. Android Studio / Android SDK is already likely installed (there is an `.android` folder).
2. Put this project in a folder, open a terminal there, and run `flutter create --platforms=android --org uz.max .` — this adds the missing `android/` folder around the code here and keeps the existing `lib/` and `pubspec.yaml`.
3. Run `flutter pub get`.
4. `lib/config.dart` already has the Supabase URL and public key filled in.
5. Open `android/app/src/main/AndroidManifest.xml` and add `<uses-permission android:name="android.permission.INTERNET"/>` just above `<application`, otherwise the release APK can't reach the internet.
6. In Supabase → Authentication → Users, click **Add user** and create Max's login (email + password). Then turn off **Allow new users to sign up** in Authentication → Sign In / Providers.
7. Enable USB debugging on the phone, plug it in, run `flutter run`.
8. Release build later: `flutter build apk --release`.
